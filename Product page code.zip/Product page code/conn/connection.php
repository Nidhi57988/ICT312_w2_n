<?php
// Database connection
$servername = "localhost";
$username = "root"; // change as per your db setup
$password = ""; // change as per your db setup
$dbname = "ICT312_website";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}