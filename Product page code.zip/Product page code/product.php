<?php
// Database connection
$servername = "localhost";
$username = "root"; // change as per your db setup
$password = ""; // change as per your db setup
$dbname = "ICT312_website";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch product data (assuming we are fetching product with id = 1)
$product_id = 1;
$sql = "SELECT * FROM products WHERE id = $product_id";
$result = $conn->query($sql);

// Check if a product was found
if ($result->num_rows > 0) {
    $product = $result->fetch_assoc();
} else {
    die("Product not found.");
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $product['name']; ?> - Product Page</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css"> <!-- Link to external CSS -->
</head>
<body id="product">
<div class="product-container">

        <div class="left-section">
            <div class="product-image">
                <div class="product-image-main">
                    <img src="<?php echo $product['image_main']; ?>" alt="" id="product-main-image">
                </div>
                <div class="product-image-slider">
                    <img src="<?php echo $product['image_1']; ?>" alt="" class="image-list" data-image="<?php echo $product['image_1']; ?>">
                    <img src="<?php echo $product['image_2']; ?>" alt="" class="image-list" data-image="<?php echo $product['image_2']; ?>">
                    <img src="<?php echo $product['image_3']; ?>" alt="" class="image-list" data-image="<?php echo $product['image_3']; ?>">
                    <img src="<?php echo $product['image_4']; ?>" alt="" class="image-list" data-image="<?php echo $product['image_4']; ?>">
                </div>
            </div>
        </div>

        <div class="right-section">
            <span class="badge">NEW</span>
            <h1 class="product-name"><?php echo $product['name']; ?></h1>
            <div class="rating">
                <span class="stars"><?php echo str_repeat('★', $product['rating']); ?></span> 
                <span class="rating-number"><?php echo $product['rating']; ?> (<?php echo $product['rating_count']; ?>)</span>
            </div>

            <p class="product-price">$<?php echo $product['price']; ?></p>
            <p class="product-code"><?php echo $product['code']; ?></p>
            <p class="product-desc"><?php echo $product['description']; ?></p>

            <h3>Choose Colour</h3>
            <div class="color-options">
                <span>Colour:</span> <span class="color-selected"><?php echo $product['color']; ?></span>
            </div>

            <div class="product-quantity">
                <input type="number" value="1" min="1" class="quantity-input">
            </div>

            <button type='button' class='product-page-button'>Add to Cart</button>
        </div>

    </div>
	// <div class="product-container">
		
	//     <div class="left-section">
	//     	<div class="product-image">
	// 		    <div class="product-image-main">
	// 		        <img src="images/tshirt-1.png" alt="" id="product-main-image">
	// 		    </div>
	// 		    <div class="product-image-slider">
	// 		        <img src="images/tshirt-1.png" alt="" class="image-list" data-image="images/tshirt-1.png">
	// 		        <img src="images/tshirt-2.png" alt="" class="image-list" data-image="images/tshirt-2.png">
	// 		        <img src="images/tshirt-3.png" alt="" class="image-list" data-image="images/tshirt-3.png">
	// 		        <img src="images/tshirt-group.png" alt="" class="image-list" data-image="images/tshirt-group.png">
	// 		    </div>
	// 		</div>
	//     </div>

	
	//     <div class="right-section">
	//     	<span class="badge">NEW</span>
    //     <h1 class='product-name'>Galaxy Watch Ultra Trail Band</h1>
    //     <div class="rating">
    //         <span class="stars">★★★★★</span> <span class="rating-number">5.0 (1)</span>
    //     </div>

    //     <p class='product-price'>$149</p>

    //     <p class="product-code">ET-SVL70MOEGWW</p>
    //     <p class="product-desc">
    //         Lightweight fabric and triangle latch and hook for a comfortable fit. One click button for effortless band switching. Lightweight fabric and triangle latch and hook for a comfortable fit. One click button for effortless band switching.
    //     </p>

    //     <h3>Choose Colour</h3>
    //     <div class="color-options">
    //         <span>Colour:</span> <span class="color-selected">Orange</span>
    //     </div>
    //     <!-- <div classs="color-selector">
    //         <label>
    //             <input type="radio" name="color" value="orange" checked>
    //             <span class="color-swatch orange"></span>
    //         </label>
    //         <label>
    //             <input type="radio" name="color" value="black">
    //             <span class="color-swatch black"></span>
    //         </label>
    //         <label>
    //             <input type="radio" name="color" value="beige">
    //             <span class="color-swatch beige"></span>
    //         </label>
    //     </div> -->


    //     <div class="product-quantity">
    //                 <input type="number" value="1" min="1" class="quantity-input">
    //             </div>


    //     <button type='button' class='product-page-button'>Added to Cart</button>
        
	//     </div>

	// </div>
    <script src="script/productimage.js"></script>
    
</body>
</html>
